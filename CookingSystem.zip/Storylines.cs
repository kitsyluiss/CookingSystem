﻿using System;

class Storylines
{
        public static string[] CampaignStory = new string[]
        {
            "My name is " +  + ", and I am just a home cook.",
            "I enjoy making food for my partner after their long workdays,",
            "and every meal I cook for them, they always enjoy.",
            "They always compliment me, saying I should be a chef for being good at cooking.",
            "\nBut one night, while frying the chicken, a bright light suddenly filled the kitchen.",
            "Before I knew it, I was taken away and woke up in a strange cage with many other chefs.",
            "They looked serious and said they were famous, but I didn’t understand why I was there with them.",
            "\nLater, we were taken to a large room, and a person called the greatest chef in the world explained why we had been chosen.",
            "They said the world was in danger because of hungry gods.",
            "If they didn’t get the best food, they would destroy everything.",
            "The chefs were supposed to make dishes so amazing that the gods would be happy.",
            "I was confused because I wasn’t a great chef like the others. I just cooked for my partner at home.",
            "\nThen, a stranger looked at me and said, “You are the one who can save us.”",
            "I was shocked and didn’t know what they meant.",
            "They said that my cooking skills were special and could reach the hearts of the gods.",
            "I didn’t believe them at first; I doubted every single word they said because I was just a chill person who cooks for my partner.",
            "But something inside me said I had to try.",
            "If my cooking could save the world, I would have to do my best, even if I were just a simple, chill home cook."
        };
    }
}

