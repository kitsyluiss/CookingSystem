﻿using System;
using System.Data.SQLite;
using System.Collections.Generic;

namespace CookingSystem
{
    class ApronCustomization : Customization
    {
        private Dictionary<string, string> _apronAttributes = new Dictionary<string, string>();

        public void SetAttribute(string key, string value)
        {
            if (_apronAttributes.ContainsKey(key))
            {
                _apronAttributes[key] = value;
            }
            else
            {
                _apronAttributes.Add(key, value);
            }
        }

        public Dictionary<string, string> GetApronAttributes()
        {
            return _apronAttributes;
        }

        public override void Customize()
        {
            Console.WriteLine("\n══════════════════════════════════════════════════════");
            Console.WriteLine("                 Customize your apron!                ");
            Console.WriteLine("══════════════════════════════════════════════════════\n");

            SetAttribute("Apron Style", ChooseOption("What style of apron does your character wear?", new Dictionary<int, string>
            {
                { 1, "Classic" },
                { 2, "Bib" },
                { 3, "Waist" },
                { 4, "Pinafore" },
                { 5, "Apron Dress" }
            }));

            SetAttribute("Apron Color", ChooseOption("What color is your character’s apron?", new Dictionary<int, string>
            {
                { 1, "White" },
                { 2, "Black" },
                { 3, "Red" },
                { 4, "Blue" },
                { 5, "Green" }
            }));

            SetAttribute("Apron Pattern", ChooseOption("What pattern is on your character’s apron?", new Dictionary<int, string>
            {
                { 1, "Solid" },
                { 2, "Stripes" },
                { 3, "Checkered" },
                { 4, "Floral" },
                { 5, "Graphic" }
            }));
        }
    }
}
