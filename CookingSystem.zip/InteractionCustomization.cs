﻿using System;
using System.Data.SQLite;
using System.Collections.Generic;

namespace CookingSystem
{
    class InteractionCustomization : Customization
    {
        private Dictionary<string, string> _interactionAttributes = new Dictionary<string, string>();

        public void SetAttribute(string key, string value)
        {
            if (_interactionAttributes.ContainsKey(key))
            {
                _interactionAttributes[key] = value;
            }
            else
            {
                _interactionAttributes.Add(key, value);
            }
        }

        public Dictionary<string, string> GetInteractionAttributes()
        {
            return _interactionAttributes;
        }


        public override void Customize()
        {
            Console.WriteLine("\n══════════════════════════════════════════════════════");
            Console.WriteLine("              Customize your interaction!             ");
            Console.WriteLine("══════════════════════════════════════════════════════");

            SetAttribute("Voice Lines", ChooseOption("Please select your character's voice line expression", new Dictionary<int, string>
            {
                { 1, "Motivational Quotes" },
                { 2, "Funny Puns" },
                { 3, "Professional Commands" },
                { 4, "Excited Cheers" },
                { 5, "Calm Remarks" }
            }));

            SetAttribute("Signature Gesture", ChooseOption("Please select your signature gesture", new Dictionary<int, string>
            {
                { 1, "Thumbs-Up" },
                { 2, "Chef's Kiss" },
                { 3, "Victory Pose" },
                { 4, "Salute" },
                { 5, "Wink" }
            }));

            SetAttribute("Culinary Partner", ChooseOption("Please select your culinary partner/pet companion", new Dictionary<int, string>
            {
                { 1, "Cat" },
                { 2, "Dog" },
                { 3, "Robot" },
                { 4, "Parrot" },
                { 5, "None" }
            }));

            SetAttribute("Theme Music", ChooseOption("Please select your theme music", new Dictionary<int, string>
            {
                { 1, "Classical" },
                { 2, "Jazzy" },
                { 3, "Upbeat" },
                { 4, "Lo-Fi Beats" },
                { 5, "Rock" }
            }));
        }
    }
}