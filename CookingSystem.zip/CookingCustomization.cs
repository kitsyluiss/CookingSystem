﻿using System;
using System.Data.SQLite;
using System.Collections.Generic;

namespace CookingSystem
{
    class CookingCustomization : Customization
    {
        private Dictionary<string, string> _cookingAttributes = new Dictionary<string, string>();

        public void SetAttribute(string key, string value)
        {
            if (_cookingAttributes.ContainsKey(key))
            {
                _cookingAttributes[key] = value;
            }
            else
            {
                _cookingAttributes.Add(key, value);
            }
        }

        public Dictionary<string, string> GetCookingAttributes() 
        { 
            return _cookingAttributes; 
        }

        public override void Customize()
        {
            Console.WriteLine("\n══════════════════════════════════════════════════════");
            Console.WriteLine("                Customize your cooking!               ");
            Console.WriteLine("══════════════════════════════════════════════════════\n");

            SetAttribute("Cooking Style", ChooseOption("Please select your cooking style", new Dictionary<int, string>
            {
                { 1, "Precise" },
                { 2, "Messy" },
                { 3, "Artistic" }
            }));

            SetAttribute("Cooking Experience", ChooseOption("What is your cooking experience level?", new Dictionary<int, string>
            {
                { 1, "Beginner" },
                { 2, "Intermediate" },
                { 3, "Master" }
            }));

            SetAttribute("Homeland", ChooseOption("Where is your character from?", new Dictionary<int, string>
            {
                { 1, "Italy" },
                { 2, "Japan" },
                { 3, "Mexico" },
                { 4, "France" },
                { 5, "India" }
            }));

            SetAttribute("Cuisine Style", ChooseOption("What type of food does your character like to cook?", new Dictionary<int, string>
            {
                { 1, "Asian" },
                { 2, "Mediterranean" },
                { 3, "French" },
                { 4, "Latin American" },
                { 5, "Fusion" }
            }));

            SetAttribute("Specialty", ChooseOption("What is your character really good at cooking?", new Dictionary<int, string>
            {
                { 1, "Sushi" },
                { 2, "BBQ" },
                { 3, "Pasta" },
                { 4, "Pastries" },
                { 5, "Stews" }
            }));

            SetAttribute("Favorite Ingredients", ChooseOption("What ingredients does your character like to use the most?", new Dictionary<int, string>
            {
                { 1, "Spices" },
                { 2, "Fresh Herbs" },
                { 3, "Seafood" },
                { 4, "Meats" },
                { 5, "Vegetables" }
            }));

            SetAttribute("Personality", ChooseOption("What is your character’s personality in the kitchen?", new Dictionary<int, string>
            {
                { 1, "Perfectionist" },
                { 2, "Creative" },
                { 3, "Competitive" },
                { 4, "Humorous" },
                { 5, "Calm" }
            }));

            SetAttribute("Voice Type", ChooseOption("What type of voice does your character have?", new Dictionary<int, string>
            {
                { 1, "Calm" },
                { 2, "Energetic" },
                { 3, "Quirky" },
                { 4, "Deep" },
                { 5, "Soft" }
            }));

            SetAttribute("Cooking Tool", ChooseOption("What is your character's preferred cooking tool?", new Dictionary<int, string>
            {
                { 1, "Knife" },
                { 2, "Whisk" },
                { 3, "Wok" },
                { 4, "Rolling Pin" },
                { 5, "Grill" }
            }));

            SetAttribute("Mood", ChooseOption("How does your character feel while cooking?", new Dictionary<int, string>
            {
                { 1, "Relaxed" },
                { 2, "Energetic" },
                { 3, "Focused" },
                { 4, "Excited" },
                { 5, "Frustrated" }
            }));
        }
    }
}
