﻿using System;
using System.Data.SQLite;
using System.Threading;

namespace CookingSystem
{
    class GameMenu : IMenu
    {
        public void CreateCharacter()
        {
            CharacterCustomization characterCustomization = new CharacterCustomization();
            characterCustomization.Customize();
            CookingCustomization cookingCustomization = new CookingCustomization();
            cookingCustomization.Customize();
            ApronCustomization apronCustomization = new ApronCustomization();
            apronCustomization.Customize();
            InteractionCustomization interactionCustomization = new InteractionCustomization();
            interactionCustomization.Customize();
            Overview.Display(characterCustomization.GetCharacterAttributes(),
                             characterCustomization.GetCharacterFlags(),
                             cookingCustomization.GetCookingAttributes(),
                             apronCustomization.GetApronAttributes(),
                             interactionCustomization.GetInteractionAttributes());
        }

        public void LoadGame()
        {
            // Load game logic
        }

        public void CampaignMode()
        {
            Console.Clear();
            Console.WriteLine("══════════════════════════════════════════════════════");
            Console.WriteLine("                     Campaign Mode");
            Console.WriteLine("══════════════════════════════════════════════════════\n");

            foreach (string line in Storylines.CampaignStory)
            {
                Console.WriteLine(line);
                Thread.Sleep(2000);
            }

            Console.WriteLine("\n══════════════════════════════════════════════════════");
            Console.WriteLine("               Press any key to continue...\n");
;
        }

        public void Credits()
        {
            Console.WriteLine("\n══════════════════════════════════════════════════════");
            Console.WriteLine("                        CREDITS                       ");
            Console.WriteLine("══════════════════════════════════════════════════════");
            Console.WriteLine("\nThis game was created by:");
            Console.WriteLine("\nRivera, Luis - Coder: Responsible for implementing the game mechanics and logic.");
            Console.WriteLine("Despabeladero, Alexis - Member: Role yet to be assigned.");
            Console.WriteLine("Crisostomo, Rafael Lorenz - Member: Role yet to be assigned.");
            Console.WriteLine("\nWe all share a love for anime, and we’re still recovering from the fact that we named this game so long it could be its own anime episode title xD\n");
        }

        public void Exit()
        {
            Console.WriteLine("\nThank you for playing, game will exit shortly.");
            Thread.Sleep(1500);
        }
    }
}
