﻿using System;
using System.Text.RegularExpressions;

namespace CookingSystem
{
    abstract class Customization 
    {
        public abstract void Customize();
        protected string ChooseUser(string prompt)
        {
            Console.WriteLine(prompt);
            string userName = Validator.GetValidatedUser();
            return userName;
        }
        
protected string ChooseOption(string prompt, Dictionary<int, string> options)
        {
            Console.WriteLine("\n" + prompt);
            foreach (var option in options)
            {
                Console.WriteLine("[" + option.Key + "] " + option.Value);
            }

            int choice = Validator.GetValidatedInput(1, options.Count);
            return options[choice];
        }

        protected bool ChooseFlag(string prompt, Dictionary<int, bool> options)
        {
            Console.WriteLine("\n" + prompt);
            foreach (var option in options)
            {
                Console.WriteLine("[" + option.Key + "] " + (option.Value ? "Yes" : "No"));
            }

            int choice = Validator.GetValidatedInput(1, options.Count);
            return options[choice];
        }
    }
}
