﻿using System;
using System.Data.SQLite;
using System.Collections.Generic;
using System.Diagnostics.Metrics;

namespace CookingSystem
{
    class CharacterCustomization : Customization
    {
        private Dictionary<string, string> _characterAttributes = new Dictionary<string, string>();
        private Dictionary<string, bool> _characterFlags = new Dictionary<string, bool>();

        public void SetAttribute(string key, string value)
        {
            if (_characterAttributes.ContainsKey(key))
            {
                _characterAttributes[key] = value;
            }
            else
            {
                _characterAttributes.Add(key, value);
            }
        }

        public void SetFlag(string key, bool value)
        {
            if (_characterFlags.ContainsKey(key))
            {
                _characterFlags[key] = value;
            }
            else
            {
                _characterFlags.Add(key, value);
            }
        }

         public string GetAttribute(string key)
        {
            return _characterAttributes.ContainsKey(key) ? _characterAttributes[key] : null;
        }

        public Dictionary<string, string> GetCharacterAttributes() 
        { 
            return _characterAttributes; 
        }

        public override void Customize()
        {
            CreateCharacter();
        }

        public void CreateCharacter()
        {
            Console.WriteLine("\n══════════════════════════════════════════════════════");
            Console.WriteLine("               Customize your character!              ");
            Console.WriteLine("══════════════════════════════════════════════════════\n");

            Console.Write("");
            SetAttribute("Username", value: ChooseUser("Enter your character's username:"));

            SetAttribute("Gender", ChooseOption("Please select your gender", new Dictionary<int, string>
            {
                { 1, "Male" },
                { 2, "Female" },
                { 3, "Non-Binary" },
                { 4, "Prefer not to say" }
            }));

            SetAttribute("Age", ChooseOption("Please select your age category", new Dictionary<int, string>
            {
                { 1, "Young" },
                { 2, "Adult" },
                { 3, "Middle-Aged" },
                { 4, "Senior" }
            }));

            SetAttribute("Skin Tone", ChooseOption("Please select your skin tone", new Dictionary<int, string>
            {
                { 1, "Fair" },
                { 2, "Light" },
                { 3, "Medium" },
                { 4, "Tan" },
                { 5, "Dark" }
            }));

            SetAttribute("Height", ChooseOption("Please select your height category", new Dictionary<int, string>
            {
                { 1, "Short" },
                { 2, "Average" },
                { 3, "Tall" },
                { 4, "Very Tall" },
                { 5, "Petite" }
            }));

            SetAttribute("Body Type", ChooseOption("Please select a body type", new Dictionary<int, string>
            {
                { 1, "Slim" },
                { 2, "Athletic" },
                { 3, "Curvy" },
                { 4, "Stocky" }
            }));

            SetAttribute("Hair Texture", ChooseOption("Please select your hair texture", new Dictionary<int, string>
            {
                { 1, "Wavy" },
                { 2, "Curly" },
                { 3, "Coiled" },
                { 4, "Straight" }
            }));

            SetAttribute("Hair Style", ChooseOption("Please select your hair style", new Dictionary<int, string>
            {
                { 1, "Long" },
                { 2, "Short" },
                { 3, "Ponytail" },
                { 4, "Buzz Cut" }
            }));

            SetAttribute("Hair Color", ChooseOption("Please select your hair color", new Dictionary<int, string>
            {
                { 1, "Black" },
                { 2, "Brown" },
                { 3, "Blonde" },
                { 4, "Red" }
            }));

            SetAttribute("Eye Color", ChooseOption("Please select your eye color", new Dictionary<int, string>
            {
                { 1, "Black" },
                { 2, "Brown" },
                { 3, "Blue" },
                { 4, "Green" },
                { 5, "Hazel" }
            }));

            SetAttribute("Outfit Style", ChooseOption("Please select an outfit style", new Dictionary<int, string>
            {
                { 1, "Chef Uniform" },
                { 2, "Casual Apron" },
                { 3, "Formal Suit" },
                { 4, "Athletic Wear" }
            }));

            SetFlag("Has Tattoo", ChooseFlag("Does your character have tattoos?", new Dictionary<int, bool>
            {
                { 1, false }, // None
                { 2, true }   // Yes
            }));

            SetFlag("Has Glasses", ChooseFlag("Does your character wear glasses?", new Dictionary<int, bool>
            {
                { 1, true },  // Yes
                { 2, false }  // No
            }));
        }
    }
}
