﻿using System;
using System.Text.RegularExpressions;

namespace CookingSystem
{
    public static class Validator
    {
        public static string GetValidatedUser()
        {
            string input = "";
            bool isValid = false;

            while (!isValid)
            {
                input = Console.ReadLine();

                if (input.Length >= 3 && input.Length <= 20 && Regex.IsMatch(input, @"^[a-zA-Z0-9]+$"))
                {
                    isValid = true;
                }
                else
                {
                    Console.WriteLine("Invalid input. Please enter a username with 3-20 characters, only letters and numbers, and no spaces.");
                }
            }
            return input;
        }

        public static int GetValidatedInput(int min, int max)
        {
            int choice;
            while (!int.TryParse(Console.ReadLine(), out choice) || choice < min || choice > max)
            {
                Console.WriteLine("Please enter a valid number between " + min + " and " + max + ".");
            }
            return choice;
        }
    }
}