﻿using System;
using System.Collections.Generic;

namespace CookingSystem
{
    class Overview
    {
        public static void Display(Dictionary<string, string> characterAttributes,
                                   Dictionary<string, bool> characterFlags,
                                   Dictionary<string, string> cookingAttributes,
                                   Dictionary<string, string> apronAttributes,
                                   Dictionary<string, string> interactionAttributes)
        {

            Console.WriteLine("\nCongrats you have successfully created a character!\n");

            Console.WriteLine("═══════ Character Attributes ═══════");
            foreach (var attribute in characterAttributes)
            {
                Console.WriteLine(attribute.Key + ": " + attribute.Value);
            }

            foreach (var flag in characterFlags)
            {
                Console.WriteLine(flag.Key + ": " + flag.Value);
            }

            Console.WriteLine("\n═══════ Cooking Customization ═══════");
            foreach (var attribute in cookingAttributes)
            {
                Console.WriteLine(attribute.Key + ": " + attribute.Value);
            }

            Console.WriteLine("\n═══════ Apron Customization ═══════");
            foreach (var attribute in apronAttributes)
            {
                Console.WriteLine(attribute.Key + ": " + attribute.Value);
            }

            Console.WriteLine("\n═══════ Interaction Customization ═══════");
            foreach (var attribute in interactionAttributes)
            {
                Console.WriteLine(attribute.Key + ": " + attribute.Value);
            }

            Console.WriteLine("\nCharacter customization complete!\n");
        }
    }
}
